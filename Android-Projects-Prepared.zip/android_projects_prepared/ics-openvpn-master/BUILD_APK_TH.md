# เตรียมโปรเจกต์ OpenVPN Android สำหรับ GitHub Actions

## สิ่งที่เพิ่ม
- `.github/workflows/build-apk.yml` สำหรับสร้าง Debug APK สองแบบ (`UiOvpn23Debug` และ `UiOvpn2Debug`)
- ตรวจสอบไฟล์ `ovpncli.i` ก่อนเริ่ม Build เพื่อแจ้งสาเหตุเมื่อ OpenVPN3 submodule ไม่พร้อม
- อัปโหลด APK เป็น GitHub Actions artifact เมื่อ Build สำเร็จ

## ข้อจำกัดที่พบใน ZIP ต้นฉบับ
ZIP มีโฟลเดอร์ `.git` ที่ไม่มี commit (`HEAD` ใช้งานไม่ได้) และโฟลเดอร์ submodule ของ OpenVPN3/OpenVPN/OpenSSL ฯลฯ ยังไม่มี source code ครบ จึงไม่สามารถรับประกันว่า Build จะผ่านเพียงแค่อัปโหลด ZIP นี้เข้า GitHub

## วิธีใช้ที่แนะนำ
1. ใช้ repository ที่เก็บซอร์สนี้อยู่จริง หรือสร้าง repository ใหม่
2. ตรวจสอบว่า `.gitmodules` และ Git submodule references ถูกเก็บไว้ครบ
3. ใน checkout ที่มี Git history ให้รัน:
   ```bash
   git submodule update --init --recursive
   ```
4. Push source และไฟล์ workflow ขึ้น branch `main` หรือ `master`
5. เปิด GitHub → Actions → `Build Android APKs` → `Run workflow`
6. หากสำเร็จ ดาวน์โหลด APK จากส่วน Artifacts ของ workflow run

## หมายเหตุ
- ZIP นี้ยังไม่ได้ผ่านการ Build จริงในสภาพแวดล้อมนี้
- การแก้ UI ของ OpenVPN ควรทำหลังจากซ่อมแหล่งที่มาของ submodules และยืนยัน Build พื้นฐานก่อน เพื่อไม่ให้กระทบการเชื่อมต่อ VPN
- โปรเจกต์ OpenVPN มีเงื่อนไขใบอนุญาต GPL และเงื่อนไขเพิ่มเติมตาม `doc/LICENSE.txt` โปรดตรวจสอบก่อนเผยแพร่แอปดัดแปลง
