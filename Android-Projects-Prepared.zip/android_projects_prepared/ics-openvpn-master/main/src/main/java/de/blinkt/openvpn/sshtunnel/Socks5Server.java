package de.blinkt.openvpn.sshtunnel;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** Minimal local SOCKS5 (CONNECT only, no auth) that forwards through a RemoteOpener. */
public final class Socks5Server implements Closeable {

    public interface Remote extends Closeable {
        InputStream in() throws IOException;
        OutputStream out() throws IOException;
    }

    public interface RemoteOpener {
        Remote open(String host, int port) throws IOException;
    }

    private final ServerSocket server;
    private final RemoteOpener opener;
    private volatile boolean closed;

    public Socks5Server(int port, RemoteOpener opener) throws IOException {
        this.server = new ServerSocket(port, 50, InetAddress.getByAddress(new byte[]{127, 0, 0, 1}));
        this.opener = opener;
    }

    public int getPort() { return server.getLocalPort(); }

    public void start() {
        Thread t = new Thread(() -> {
            while (!closed) {
                try {
                    Socket c = server.accept();
                    new Thread(() -> handle(c), "socks-client").start();
                } catch (IOException e) {
                    if (!closed) continue; else break;
                }
            }
        }, "socks-accept");
        t.setDaemon(true);
        t.start();
    }

    private void handle(Socket c) {
        Remote r = null;
        try {
            c.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(c.getInputStream());
            OutputStream out = c.getOutputStream();
            if (in.readUnsignedByte() != 5) throw new IOException("not SOCKS5");
            int n = in.readUnsignedByte();
            in.readFully(new byte[n]);
            out.write(new byte[]{5, 0});
            out.flush();

            in.readUnsignedByte();              // VER
            int cmd = in.readUnsignedByte();
            in.readUnsignedByte();              // RSV
            int atyp = in.readUnsignedByte();
            String host;
            if (atyp == 1) {
                byte[] a = new byte[4]; in.readFully(a);
                host = InetAddress.getByAddress(a).getHostAddress();
            } else if (atyp == 3) {
                byte[] a = new byte[in.readUnsignedByte()]; in.readFully(a);
                host = new String(a, "ISO-8859-1");
            } else if (atyp == 4) {
                byte[] a = new byte[16]; in.readFully(a);
                host = InetAddress.getByAddress(a).getHostAddress();
            } else {
                reply(out, 8); c.close(); return;
            }
            int port = in.readUnsignedShort();
            if (cmd != 1) { reply(out, 7); c.close(); return; }

            try {
                r = opener.open(host, port);
            } catch (IOException e) {
                reply(out, 5); c.close(); return;
            }
            reply(out, 0);

            final Remote remote = r;
            Thread up = new Thread(() -> pump(c, remote), "socks-up");
            up.setDaemon(true);
            up.start();
            pumpStreams(remote.in(), out);
        } catch (IOException ignored) {
        } finally {
            try { c.close(); } catch (IOException ignored) {}
            if (r != null) try { r.close(); } catch (IOException ignored) {}
        }
    }

    private static void pump(Socket c, Remote r) {
        try { pumpStreams(c.getInputStream(), r.out()); }
        catch (IOException ignored) {}
        finally {
            try { c.close(); } catch (IOException ignored) {}
            try { r.close(); } catch (IOException ignored) {}
        }
    }

    private static void pumpStreams(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) >= 0) {
            out.write(buf, 0, n);
            out.flush();
        }
    }

    private static void reply(OutputStream out, int code) throws IOException {
        out.write(new byte[]{5, (byte) code, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    @Override public void close() throws IOException {
        closed = true;
        server.close();
    }
}
