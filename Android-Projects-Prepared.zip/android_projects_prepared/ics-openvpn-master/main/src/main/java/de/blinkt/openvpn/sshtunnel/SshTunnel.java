package de.blinkt.openvpn.sshtunnel;

import com.jcraft.jsch.ChannelDirectTCPIP;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SocketFactory;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/** SSH session carried over an HTTP-payload socket, exposed as a local SOCKS5 proxy. */
public final class SshTunnel implements Closeable {

    public static final class Config {
        public String sshHost, user, pass, proxyHost, sni, payload;
        public int sshPort = 22, proxyPort = 80, socksPort = 1080, expectStatus = 0;
        public boolean tls, usePayload;
    }

    private Session session;
    private Socks5Server socks;

    public synchronized void start(final Config c) throws Exception {
        close();
        JSch jsch = new JSch();
        Session s = jsch.getSession(c.user, c.sshHost, c.sshPort);
        s.setPassword(c.pass);
        // TODO: trust-on-first-use host key check. "no" accepts any key (MITM risk).
        s.setConfig("StrictHostKeyChecking", "no");
        s.setServerAliveInterval(15000);
        s.setSocketFactory(new SocketFactory() {
            @Override public Socket createSocket(String host, int port) throws IOException {
                if (!c.usePayload) {
                    Socket direct = new Socket();
                    direct.connect(new java.net.InetSocketAddress(c.sshHost, c.sshPort), 15000);
                    direct.setTcpNoDelay(true);
                    return direct;
                }
                return HttpPayloadConnector.connect(c.proxyHost, c.proxyPort, c.tls, c.sni,
                        c.sshHost, c.sshPort, c.payload, c.expectStatus, 15000, null);
            }
            @Override public InputStream getInputStream(Socket so) throws IOException { return so.getInputStream(); }
            @Override public OutputStream getOutputStream(Socket so) throws IOException { return so.getOutputStream(); }
        });
        s.connect(20000);
        session = s;

        socks = new Socks5Server(c.socksPort, (host, port) -> {
            final ChannelDirectTCPIP ch = (ChannelDirectTCPIP) session.openChannel("direct-tcpip");
            ch.setHost(host);
            ch.setPort(port);
            final InputStream in;
            final OutputStream out;
            try {
                in = ch.getInputStream();
                out = ch.getOutputStream();
                ch.connect(15000);
            } catch (Exception e) {
                throw new IOException(e);
            }
            return new Socks5Server.Remote() {
                @Override public InputStream in() { return in; }
                @Override public OutputStream out() { return out; }
                @Override public void close() { ch.disconnect(); }
            };
        });
        socks.start();
    }

    public synchronized boolean isConnected() { return session != null && session.isConnected(); }

    @Override public synchronized void close() {
        try { if (socks != null) socks.close(); } catch (IOException ignored) {}
        if (session != null) session.disconnect();
        socks = null; session = null;
    }
}
