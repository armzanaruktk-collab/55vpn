package de.blinkt.openvpn.sshtunnel;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Stores user-added servers and payloads as JSON in SharedPreferences. */
public final class TunnelStore {
    private final SharedPreferences sp;
    public TunnelStore(Context c) { sp = c.getSharedPreferences("ssh_tunnel", Context.MODE_PRIVATE); }

    public List<JSONObject> list(String key) {
        List<JSONObject> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i));
        } catch (JSONException ignored) {}
        return out;
    }

    public void add(String key, JSONObject o) {
        List<JSONObject> l = list(key);
        l.add(o);
        save(key, l);
    }

    public void remove(String key, int index) {
        List<JSONObject> l = list(key);
        if (index >= 0 && index < l.size()) { l.remove(index); save(key, l); }
    }

    public static String ovpnKey(String uuid) { return "ovpn_payload:" + uuid; }

    public JSONObject getJson(String key) {
        String v = sp.getString(key, null);
        if (v == null) return null;
        try { return new JSONObject(v); } catch (JSONException e) { return null; }
    }

    public void putJson(String key, JSONObject o) { sp.edit().putString(key, o.toString()).apply(); }

    public void removeKey(String key) { sp.edit().remove(key).apply(); }

    private void save(String key, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp.edit().putString(key, a.toString()).apply();
    }
}
