package de.blinkt.openvpn.sshtunnel;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Local TCP listener (127.0.0.1). Every accepted connection is carried to the target through
 * an HTTP-payload handshake with the front host, then piped raw. Lets OpenVPN (TCP) use a payload
 * by pointing its "remote" at 127.0.0.1:getLocalPort().
 */
public final class PayloadForwarder implements Closeable {

    public static final class Config {
        public String proxyHost, sni, targetHost, payload;
        public int proxyPort = 80, targetPort = 1194, expectStatus = 0;
        public boolean tls;
    }

    private final ServerSocket server;
    private final Config cfg;
    private final HttpPayloadConnector.SocketProtector protector;
    private volatile boolean closed;

    public PayloadForwarder(Config cfg, HttpPayloadConnector.SocketProtector protector) throws IOException {
        this.cfg = cfg;
        this.protector = protector;
        this.server = new ServerSocket(0, 20, InetAddress.getByAddress(new byte[]{127, 0, 0, 1}));
    }

    public int getLocalPort() { return server.getLocalPort(); }

    public void start() {
        Thread t = new Thread(() -> {
            while (!closed) {
                try {
                    final Socket c = server.accept();
                    Thread h = new Thread(() -> handle(c), "payload-fwd");
                    h.setDaemon(true);
                    h.start();
                } catch (IOException e) {
                    if (closed) break;
                }
            }
        }, "payload-accept");
        t.setDaemon(true);
        t.start();
    }

    private void handle(final Socket c) {
        Socket up = null;
        try {
            c.setTcpNoDelay(true);
            up = HttpPayloadConnector.connect(cfg.proxyHost, cfg.proxyPort, cfg.tls, cfg.sni,
                    cfg.targetHost, cfg.targetPort, cfg.payload, cfg.expectStatus, 15000, protector);
            final Socket u = up;
            Thread t = new Thread(() -> pipe(c, u), "payload-up");
            t.setDaemon(true);
            t.start();
            pipe(u, c);
        } catch (IOException ignored) {
        } finally {
            try { c.close(); } catch (IOException ignored) {}
            if (up != null) try { up.close(); } catch (IOException ignored) {}
        }
    }

    private static void pipe(Socket from, Socket to) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) >= 0) { out.write(buf, 0, n); out.flush(); }
        } catch (IOException ignored) {
        } finally {
            try { from.close(); } catch (IOException ignored) {}
            try { to.close(); } catch (IOException ignored) {}
        }
    }

    @Override public void close() throws IOException {
        closed = true;
        server.close();
    }
}
