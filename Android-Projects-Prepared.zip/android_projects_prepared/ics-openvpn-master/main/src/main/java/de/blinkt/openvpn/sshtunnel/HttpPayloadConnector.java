package de.blinkt.openvpn.sshtunnel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Opens a TCP (optionally TLS) connection to a proxy / front host, sends the
 * user's HTTP payload and returns the socket once the server answers 101 or 2xx.
 * After that the socket is a raw byte pipe to the SSH server.
 */
public final class HttpPayloadConnector {
    private HttpPayloadConnector() {}

    /** Lets a VpnService exclude the outgoing socket from the VPN (VpnService.protect). */
    public interface SocketProtector { boolean protect(Socket s); }

    public static Socket connect(String proxyHost, int proxyPort, boolean tls, String sni,
                                 String sshHost, int sshPort, String payloadTemplate,
                                 int timeoutMs) throws IOException {
        return connect(proxyHost, proxyPort, tls, sni, sshHost, sshPort, payloadTemplate,
                0, timeoutMs, null);
    }

    /** expectStatus: 0 = accept 101 or any 2xx, otherwise the exact status code required. */
    public static Socket connect(String proxyHost, int proxyPort, boolean tls, String sni,
                                 String sshHost, int sshPort, String payloadTemplate,
                                 int expectStatus, int timeoutMs, SocketProtector protector)
            throws IOException {
        Socket raw;
        if (protector != null) {
            raw = java.nio.channels.SocketChannel.open().socket(); // real fd exists before connect
            if (!protector.protect(raw)) {
                raw.close();
                throw new IOException("Could not protect socket from VPN");
            }
        } else {
            raw = new Socket();
        }
        raw.connect(new InetSocketAddress(proxyHost, proxyPort), timeoutMs);
        raw.setTcpNoDelay(true);
        raw.setSoTimeout(timeoutMs);
        Socket s = raw;
        try {
            if (tls) {
                String name = (sni == null || sni.isEmpty()) ? proxyHost : sni;
                SSLSocket ssl = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault())
                        .createSocket(raw, name, proxyPort, true);
                SSLParameters p = ssl.getSSLParameters();
                p.setServerNames(java.util.Collections.singletonList(new SNIHostName(name)));
                ssl.setSSLParameters(p);
                ssl.startHandshake();
                s = ssl;
            }
            String payload = PayloadTemplate.render(payloadTemplate, sshHost, sshPort);
            OutputStream out = s.getOutputStream();
            out.write(payload.getBytes(StandardCharsets.ISO_8859_1));
            out.flush();

            String status = readHeaders(s.getInputStream());
            int code = parseStatus(status);
            boolean ok = expectStatus > 0 ? code == expectStatus
                                          : (code == 101 || (code >= 200 && code <= 299));
            if (!ok) {
                throw new IOException("Proxy replied: " + status);
            }
            s.setSoTimeout(0);
            return s;
        } catch (IOException | RuntimeException e) {
            try { s.close(); } catch (IOException ignored) {}
            throw e;
        }
    }

    /** Reads byte by byte so nothing after the blank line is consumed. Returns the status line. */
    static String readHeaders(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int state = 0; // matches \r\n\r\n
        while (state < 4) {
            int b = in.read();
            if (b < 0) throw new IOException("Connection closed before response");
            sb.append((char) b);
            if (sb.length() > 16384) throw new IOException("Response header too large");
            if ((b == '\r' && (state == 0 || state == 2)) || (b == '\n' && (state == 1 || state == 3))) {
                state++;
            } else {
                state = (b == '\r') ? 1 : 0;
            }
        }
        int eol = sb.indexOf("\r\n");
        return sb.substring(0, eol);
    }

    static int parseStatus(String line) {
        String[] parts = line.split(" ");
        if (parts.length < 2) return -1;
        try { return Integer.parseInt(parts[1]); } catch (NumberFormatException e) { return -1; }
    }
}
