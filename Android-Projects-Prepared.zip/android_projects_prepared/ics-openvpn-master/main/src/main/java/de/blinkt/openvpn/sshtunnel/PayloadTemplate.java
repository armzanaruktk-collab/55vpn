package de.blinkt.openvpn.sshtunnel;

/** Expands HTTP-payload placeholders such as [crlf], [host_port], [host], [port]. */
public final class PayloadTemplate {
    private PayloadTemplate() {}

    public static String render(String template, String host, int port) {
        if (template == null) return "";
        String s = template;
        s = s.replace("[host_port]", host + ":" + port);
        s = s.replace("[host]", host);
        s = s.replace("[port]", String.valueOf(port));
        s = s.replace("[protocol]", "HTTP/1.1");
        s = s.replace("[crlf]", "\r\n");
        s = s.replace("[cr]", "\r");
        s = s.replace("[lf]", "\n");
        s = s.replace("\\r", "\r").replace("\\n", "\n");
        // Text typed in a multi-line box: normalise bare line breaks to CRLF
        s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n");
        // A request must end with an empty line
        if (!s.endsWith("\r\n\r\n")) {
            s = s.endsWith("\r\n") ? s + "\r\n" : s + "\r\n\r\n";
        }
        return s;
    }
}
