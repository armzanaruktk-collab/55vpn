package de.blinkt.openvpn.sshtunnel;

import android.net.VpnService;
import de.blinkt.openvpn.VpnProfile;
import de.blinkt.openvpn.core.Connection;
import de.blinkt.openvpn.core.VpnStatus;
import org.json.JSONObject;

/**
 * If the user enabled an HTTP payload for an OpenVPN profile, start a local PayloadForwarder and
 * temporarily point the profile's (TCP) remote at 127.0.0.1:port. restore() undoes it.
 */
public final class OvpnPayloadHook {
    private static PayloadForwarder forwarder;
    private static VpnProfile patched;
    private static Connection[] original;

    private OvpnPayloadHook() {}

    public static synchronized void apply(final VpnService svc, VpnProfile p) {
        restore();
        JSONObject j = new TunnelStore(svc).getJson(TunnelStore.ovpnKey(p.getUUIDString()));
        if (j == null) return;

        Connection target = null;
        for (Connection c : p.mConnections) {
            if (c.mEnabled && !c.mUseUdp) { target = c; break; }
        }
        if (target == null) {
            VpnStatus.logInfo("HTTP payload skipped: profile has no enabled TCP remote");
            return;
        }
        try {
            PayloadForwarder.Config cfg = new PayloadForwarder.Config();
            cfg.targetHost = target.mServerName;
            cfg.targetPort = Integer.parseInt(target.mServerPort.trim());
            cfg.proxyHost = j.optString("proxyHost", "").isEmpty() ? target.mServerName : j.optString("proxyHost");
            cfg.proxyPort = j.optInt("proxyPort", 80);
            cfg.tls = j.optBoolean("tls");
            cfg.sni = j.optString("sni", "");
            cfg.payload = j.optString("payload", "");
            cfg.expectStatus = j.optInt("expect", 0);

            forwarder = new PayloadForwarder(cfg, s -> svc.protect(s));
            forwarder.start();

            Connection local = new Connection();
            local.mServerName = "127.0.0.1";
            local.mServerPort = String.valueOf(forwarder.getLocalPort());
            local.mUseUdp = false;
            local.mEnabled = true;
            local.mConnectTimeout = target.mConnectTimeout;

            original = p.mConnections;
            patched = p;
            p.mConnections = new Connection[]{local};
            VpnStatus.logInfo("HTTP payload active via 127.0.0.1:" + local.mServerPort);
        } catch (Exception e) {
            VpnStatus.logInfo("HTTP payload setup failed: " + e);
            restore();
        }
    }

    public static synchronized void restore() {
        if (patched != null && original != null) patched.mConnections = original;
        patched = null;
        original = null;
        if (forwarder != null) {
            try { forwarder.close(); } catch (Exception ignored) {}
            forwarder = null;
        }
    }
}
