package de.blinkt.openvpn.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import de.blinkt.openvpn.R
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.sshtunnel.TunnelStore
import org.json.JSONObject

class EditProfileActivity : AppCompatActivity() {
    private lateinit var store: TunnelStore
    private var ovpnProfiles: List<Pair<String, String>> = emptyList() // name to uuid
    private var payloads: List<JSONObject> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        title = "เพิ่มโปรไฟล์"
        store = TunnelStore(this)

        val rgKind = findViewById<RadioGroup>(R.id.rgKind)
        val groupSsh = findViewById<View>(R.id.groupSsh)
        val groupOvpn = findViewById<View>(R.id.groupOvpn)
        val swPayload = findViewById<CompoundButton>(R.id.swPayload)
        val groupPayload = findViewById<View>(R.id.groupPayload)

        rgKind.setOnCheckedChangeListener { _, id ->
            val ovpn = id == R.id.rbOvpn
            groupSsh.visibility = if (ovpn) View.GONE else View.VISIBLE
            groupOvpn.visibility = if (ovpn) View.VISIBLE else View.GONE
        }
        swPayload.setOnCheckedChangeListener { _, on ->
            groupPayload.visibility = if (on) View.VISIBLE else View.GONE
        }
        findViewById<View>(R.id.btnImportOvpn).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        findViewById<View>(R.id.btnAddPayload).setOnClickListener {
            PayloadDialog.show(this, store) { loadPayloads(selectLast = true) }
        }
        findViewById<View>(R.id.btnDelPayload).setOnClickListener {
            val i = findViewById<Spinner>(R.id.spPayload).selectedItemPosition
            if (i >= 0) { store.remove(PayloadDialog.KEY, i); loadPayloads(false) }
        }
        findViewById<View>(R.id.btnSave).setOnClickListener { save() }
        loadPayloads(false)
    }

    override fun onResume() {
        super.onResume()
        loadOvpnProfiles() // refresh after importing a file
    }

    private fun loadOvpnProfiles() {
        ovpnProfiles = ProfileManager.getInstance(this).profiles.map { it.name to it.uuidString }
        findViewById<Spinner>(R.id.spOvpn).adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, ovpnProfiles.map { it.first })
    }

    private fun loadPayloads(selectLast: Boolean) {
        payloads = store.list(PayloadDialog.KEY)
        val sp = findViewById<Spinner>(R.id.spPayload)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, payloads.map {
            val d = it.optString("desc")
            "[${it.optString("type").uppercase()}] ${it.optString("name")}" + if (d.isEmpty()) "" else " — $d"
        })
        if (selectLast && payloads.isNotEmpty()) sp.setSelection(payloads.size - 1)
    }

    private fun txt(id: Int) = findViewById<EditText>(id).text.toString().trim()

    private fun save() {
        val ovpn = findViewById<RadioGroup>(R.id.rgKind).checkedRadioButtonId == R.id.rbOvpn
        val usePayload = findViewById<CompoundButton>(R.id.swPayload).isChecked
        val o = JSONObject().put("kind", if (ovpn) "ovpn" else "ssh").put("usePayload", usePayload)

        if (ovpn) {
            val idx = findViewById<Spinner>(R.id.spOvpn).selectedItemPosition
            if (idx < 0 || idx >= ovpnProfiles.size) {
                Toast.makeText(this, "ยังไม่มีโปรไฟล์ .ovpn — กดนำเข้าก่อน", Toast.LENGTH_LONG).show(); return
            }
            o.put("name", ovpnProfiles[idx].first).put("ovpnUuid", ovpnProfiles[idx].second)
        } else {
            if (txt(R.id.etRemarks).isEmpty() || txt(R.id.etHost).isEmpty()) {
                Toast.makeText(this, "กรอกชื่อและ Address", Toast.LENGTH_SHORT).show(); return
            }
            o.put("name", txt(R.id.etRemarks)).put("host", txt(R.id.etHost))
                .put("port", txt(R.id.etPort).toIntOrNull() ?: 22)
                .put("user", txt(R.id.etUser)).put("pass", txt(R.id.etPass))
        }
        if (usePayload) {
            val pi = findViewById<Spinner>(R.id.spPayload).selectedItemPosition
            if (pi < 0 || pi >= payloads.size) {
                Toast.makeText(this, "ยังไม่มีเพย์โหลด — กดเพิ่มเพย์โหลดก่อน", Toast.LENGTH_LONG).show(); return
            }
            val pl = payloads[pi]
            // Copy a snapshot so the profile keeps working even if the payload is deleted later
            o.put("payload", pl.optString("payload")).put("expect", 0)
                .put("proxyHost", pl.optString("proxyHost")).put("proxyPort", pl.optInt("port", 80))
                .put("tls", pl.optBoolean("tls")).put("sni", "")
                .put("payloadName", pl.optString("name"))
        }
        store.add("profiles", o)
        finish()
    }
}
