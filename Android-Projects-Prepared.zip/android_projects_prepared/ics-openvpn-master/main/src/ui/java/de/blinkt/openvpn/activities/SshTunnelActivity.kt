package de.blinkt.openvpn.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import de.blinkt.openvpn.LaunchVPN
import de.blinkt.openvpn.R
import de.blinkt.openvpn.sshtunnel.SshTunnel
import de.blinkt.openvpn.sshtunnel.TunnelStore
import org.json.JSONObject
import kotlin.concurrent.thread

class SshTunnelActivity : AppCompatActivity() {
    private lateinit var store: TunnelStore
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var btnConnect: Button

    companion object {
        private val tunnel = SshTunnel()
        private const val PROFILES = "profiles"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ssh_tunnel)
        store = TunnelStore(this)
        list = findViewById(R.id.lvProfiles)
        status = findViewById(R.id.tvStatus)
        btnConnect = findViewById(R.id.btnConnect)

        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            val i = list.checkedItemPosition
            if (i >= 0) { store.remove(PROFILES, i); refresh() }
        }
        btnConnect.setOnClickListener { onConnectClicked() }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun label(p: JSONObject): String {
        val kind = if (p.optString("kind") == "ovpn") "OVPN" else "SSH"
        val pl = if (p.optBoolean("usePayload")) " + Payload" else ""
        return "[$kind$pl] ${p.optString("name")}"
    }

    private fun refresh() {
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice,
            store.list(PROFILES).map { label(it) })
        btnConnect.text = if (tunnel.isConnected) "ตัดการเชื่อมต่อ SSH" else "เชื่อมต่อ"
    }

    private fun onConnectClicked() {
        if (tunnel.isConnected) {
            thread { tunnel.close(); runOnUiThread { status.text = "หยุดเชื่อมต่อแล้ว"; refresh() } }
            return
        }
        val i = list.checkedItemPosition
        val profiles = store.list(PROFILES)
        if (i < 0 || i >= profiles.size) { status.text = "เลือกโปรไฟล์ก่อน"; return }
        val p = profiles[i]
        if (p.optString("kind") == "ovpn") connectOvpn(p) else connectSsh(p)
    }

    private fun connectOvpn(p: JSONObject) {
        val uuid = p.optString("ovpnUuid")
        val key = TunnelStore.ovpnKey(uuid)
        if (p.optBoolean("usePayload")) {
            store.putJson(key, JSONObject()
                .put("payload", p.optString("payload")).put("expect", p.optInt("expect"))
                .put("proxyHost", p.optString("proxyHost")).put("proxyPort", p.optInt("proxyPort", 80))
                .put("tls", p.optBoolean("tls")).put("sni", p.optString("sni")))
        } else {
            store.removeKey(key)
        }
        status.text = "เริ่ม OpenVPN — ดูสถานะที่หน้าหลักของ OpenVPN"
        startActivity(Intent(this, LaunchVPN::class.java).apply {
            action = Intent.ACTION_MAIN
            putExtra(LaunchVPN.EXTRA_KEY, uuid)
        })
    }

    private fun connectSsh(p: JSONObject) {
        val c = SshTunnel.Config().apply {
            sshHost = p.optString("host"); sshPort = p.optInt("port", 22)
            user = p.optString("user"); pass = p.optString("pass")
            usePayload = p.optBoolean("usePayload")
            proxyHost = p.optString("proxyHost").ifEmpty { sshHost }
            proxyPort = p.optInt("proxyPort", 80)
            tls = p.optBoolean("tls"); sni = p.optString("sni")
            payload = p.optString("payload"); expectStatus = p.optInt("expect", 0)
        }
        btnConnect.isEnabled = false
        status.text = "กำลังเชื่อมต่อ..."
        thread {
            val err = try { tunnel.start(c); null } catch (e: Exception) { e.message ?: e.toString() }
            runOnUiThread {
                btnConnect.isEnabled = true
                status.text = if (err == null) "เชื่อมต่อแล้ว — SOCKS5 127.0.0.1:${c.socksPort}" else "ล้มเหลว: $err"
                refresh()
            }
        }
    }
}
