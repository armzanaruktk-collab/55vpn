package de.blinkt.openvpn.activities

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import de.blinkt.openvpn.R
import de.blinkt.openvpn.sshtunnel.TunnelStore
import org.json.JSONObject

/** "Add payload" dialog. Saved payloads live in TunnelStore under KEY and are reused by profiles. */
object PayloadDialog {
    const val KEY = "payloads"
    private const val TPL_WS = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]"
    private const val TPL_HTTP = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf][crlf]"

    fun show(ctx: Context, store: TunnelStore, onSaved: () -> Unit) {
        val v = LayoutInflater.from(ctx).inflate(R.layout.dialog_add_payload, null)
        val rg = v.findViewById<RadioGroup>(R.id.rgType)
        val etPayload = v.findViewById<EditText>(R.id.etPayload)
        val etPort = v.findViewById<EditText>(R.id.etPort)
        val swTls = v.findViewById<CompoundButton>(R.id.swTls)
        fun t(id: Int) = v.findViewById<EditText>(id).text.toString().trim()

        etPayload.setText(TPL_WS)
        rg.setOnCheckedChangeListener { _, id ->
            when (id) {
                R.id.rbWs -> { etPayload.setText(TPL_WS); etPort.setText("80"); swTls.isChecked = false }
                R.id.rbHttp -> { etPayload.setText(TPL_HTTP); etPort.setText("80"); swTls.isChecked = false }
                R.id.rbSsl -> { etPayload.setText(TPL_WS); etPort.setText("443"); swTls.isChecked = true }
            }
        }

        val dlg = AlertDialog.Builder(ctx).setView(v).create()
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
        v.findViewById<View>(R.id.btnCancel).setOnClickListener { dlg.dismiss() }
        v.findViewById<View>(R.id.btnSave).setOnClickListener {
            if (t(R.id.etPlName).isEmpty() || etPayload.text.isBlank()) {
                Toast.makeText(ctx, "กรอกชื่อและเพย์โหลด", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            val type = when (rg.checkedRadioButtonId) {
                R.id.rbHttp -> "http"; R.id.rbSsl -> "ssl"; else -> "ws"
            }
            store.add(KEY, JSONObject()
                .put("name", t(R.id.etPlName)).put("desc", t(R.id.etPlDesc)).put("type", type)
                .put("payload", etPayload.text.toString())
                .put("tls", swTls.isChecked)
                .put("proxyHost", t(R.id.etProxy))
                .put("port", etPort.text.toString().toIntOrNull() ?: 80))
            onSaved()
            dlg.dismiss()
        }
        dlg.show()
    }
}
