ไฟล์ Messenger.zip ที่ได้รับมีภาพ JPEG 10 ภาพเท่านั้น ไม่มี Android source code, Gradle project หรือ AndroidManifest.xml
จึงใช้เป็นภาพอ้างอิงสำหรับออกแบบ UI ได้ แต่ไม่สามารถ Build APK จากไฟล์นี้โดยตรง
หากต้องการให้สร้างแอป Android ใหม่จากภาพเหล่านี้ ต้องจัดทำโครงสร้างโปรเจกต์และเขียนโค้ด UI ขึ้นใหม่
